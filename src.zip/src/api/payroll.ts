// src/api/payroll.ts
export type PayrollTotals = {
  hours: number
  food_allowance_iqd: number
  other_allowance_iqd: number
  allowances_iqd: number
  base_salary_iqd: number
  total_pay_iqd: number
}

export type PayrollRow = {
  uid: string
  code?: string
  name: string
  branch: string
  nationality: string
  days: Record<string, number>
  totals: PayrollTotals
  meta?: {
    employment_type?: 'wages' | 'salary' | string | null
    hourly_rate?: number
    salary_iqd?: number
    uid?: string
    auto_allowances_iqd?: number
    manual_adjustments_iqd?: number
  }
}

function getApiBase(): string {
  try {
    const s = (window as any)?.__AUTH_STORE__?.getState?.() || (window as any)?.useAuthStore?.getState?.()
    const b = s?.apiBase as string | undefined
    if (b) return b.replace(/\/+$/, '')
  } catch {}
  const env = (import.meta as any)?.env?.VITE_API_URL as string | undefined
  if (env) return env.replace(/\/+$/, '')
  const url = new URL(window.location.href)
  const port = url.port === '5173' ? '8000' : url.port
  return `${url.protocol}//${url.hostname}${port ? ':' + port : ''}`
}

function tokenHeader() {
  let t: string | undefined
  try { t = (window as any)?.useAuthStore?.getState?.().token } catch {}
  t = t || localStorage.getItem('jwt') || localStorage.getItem('token') ||
      localStorage.getItem('auth_token') || localStorage.getItem('access_token') || ''
  return t ? { Authorization: /^bearer\s/i.test(t) ? t : `Bearer ${t}` } : {}
}

export async function getPayroll(params: { from: string; to: string; branch?: string }): Promise<PayrollRow[]> {
  const q = new URLSearchParams()
  q.set('from', params.from)
  q.set('to', params.to)
  if (params.branch) q.set('branch', params.branch)

  const res = await fetch(`${getApiBase()}/payroll?${q.toString()}`, { headers: { ...tokenHeader() } })
  if (!res.ok) throw new Error(`Payroll fetch failed: ${res.status}`)

  const raw = await res.json()
  const arr: any[] = Array.isArray(raw) ? raw : []

  return arr.map((r) => {
    const uid = String(r.uid || r?.meta?.uid || r?.UID || r?.Uid || '').toUpperCase()
    const days = typeof r.days === 'object' && r.days ? r.days : {}
    const t = r.totals || {}

    const row: PayrollRow = {
      uid,
      code: r.code ?? '',
      name: r.name ?? '',
      branch: r.branch ?? '',
      nationality: String(r.nationality ?? '').toLowerCase(),
      days,
      totals: {
        hours: Number(t.hours ?? 0),
        food_allowance_iqd: Number(t.food_allowance_iqd ?? t.auto_allowances_iqd ?? 0),
        other_allowance_iqd: Number(t.other_allowance_iqd ?? t.manual_adjustments_iqd ?? 0),
        allowances_iqd: Number(t.allowances_iqd ?? (Number(t.food_allowance_iqd ?? 0) + Number(t.other_allowance_iqd ?? 0))),
        base_salary_iqd: Number(t.base_salary_iqd ?? 0),
        total_pay_iqd: Number(t.total_pay_iqd ?? 0),
      },
      meta: {
        ...r.meta,
        uid,
      },
    }
    return row
  })
}
